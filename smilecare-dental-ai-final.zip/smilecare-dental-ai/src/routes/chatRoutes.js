/**
 * Chat Routes
 * Defines all API routes for the SmileCare Dental AI Agent.
 */

const express = require("express");
const router  = express.Router();

const { handleChat, healthCheck }           = require("../controllers/chatController");
const { chatValidationRules, validate }     = require("../utils/validators");

// Health check
router.get("/health", healthCheck);

// Main chat endpoint
router.post("/chat", chatValidationRules, validate, handleChat);

module.exports = router;
