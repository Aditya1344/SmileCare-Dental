/**
 * Agent Service
 * Core business logic: processes user messages, detects intent,
 * and generates context-aware responses for SmileCare Dental.
 */

const { callLLM, extractService, extractDate, INTENTS } = require("../utils/mockAI");
const clinicData = require("../data/clinicData");
const logger = require("../utils/logger");

// ─── Response Builders ────────────────────────────────────────────────────────

function buildBookingResponse(message) {
  const service = extractService(message);
  const date    = extractDate(message);

  // Build a natural reply
  let reply;
  if (service && date) {
    reply = `Sure! I can help you book a ${service} appointment on ${date}. We will confirm your booking via email at ${clinicData.email} or you can call us at ${clinicData.phone}.`;
  } else if (service) {
    reply = `Sure! I can help you book a ${service} appointment. Could you please let me know your preferred date? We are available ${clinicData.operatingHours.humanReadable}.`;
  } else if (date) {
    reply = `I'd love to help you book an appointment on ${date}! Which service are you interested in? We offer: ${clinicData.services.map((s) => s.name).join(", ")}.`;
  } else {
    reply = `I'd be happy to help you book an appointment at ${clinicData.name}! Please let me know your preferred service and date. We are open ${clinicData.operatingHours.humanReadable}.`;
  }

  return {
    reply,
    intent:  INTENTS.BOOK_APPOINTMENT,
    service: service || null,
    date:    date || null,
  };
}

function buildTimingsResponse() {
  const { days, open, close } = clinicData.operatingHours;
  return {
    reply:  `We are open ${days} from ${open} to ${close}. For appointments or queries, call us at ${clinicData.phone} or email ${clinicData.email}.`,
    intent: INTENTS.ASK_TIMINGS,
  };
}

function buildServicesResponse() {
  const serviceList = clinicData.services.map((s) => s.name).join(", ");
  return {
    reply:  `At ${clinicData.name}, we provide: ${serviceList}. Feel free to ask about any service or book an appointment!`,
    intent: INTENTS.ASK_SERVICES,
  };
}

function buildGeneralResponse(message) {
  const msg = message.toLowerCase().trim();

  // Greeting detection
  if (/^(hi|hello|hey|howdy|good morning|good afternoon|good evening|greetings|what'?s up)/.test(msg)) {
    return {
      reply:  `Hello! Welcome to ${clinicData.name} 😊. How can I assist you today? You can ask me about our services, timings, or book an appointment!`,
      intent: INTENTS.GENERAL_QUERY,
    };
  }

  // Thank you detection
  if (/thank|thanks|thank you/.test(msg)) {
    return {
      reply:  `You're welcome! 😊 Feel free to reach out anytime. Have a great day and smile bright! 🦷`,
      intent: INTENTS.GENERAL_QUERY,
    };
  }

  // Contact info request
  if (/contact|phone|email|number|reach/.test(msg)) {
    return {
      reply:  `You can reach ${clinicData.name} at 📞 ${clinicData.phone} or ✉️ ${clinicData.email}. We are available ${clinicData.operatingHours.humanReadable}.`,
      intent: INTENTS.GENERAL_QUERY,
    };
  }

  // Fallback
  return {
    reply:  `Thanks for reaching out to ${clinicData.name}! I can help you with: \n• Our services (Dental Cleaning, Root Canal, Braces, Teeth Whitening)\n• Operating hours\n• Booking appointments\n\nHow can I assist you today?`,
    intent: INTENTS.GENERAL_QUERY,
  };
}

// ─── Main Agent Processor ─────────────────────────────────────────────────────

/**
 * Processes the user's chat message and returns a structured response.
 * @param {string} message - The user's input message
 * @returns {Object} Agent response with reply, intent, and optional metadata
 */
async function processMessage(message) {
  logger.info("Processing message", { message });

  // Step 1: Detect intent via mock AI
  const { intent } = await callLLM(message);
  logger.debug("Intent detected", { intent });

  // Step 2: Route to appropriate response builder
  let response;
  switch (intent) {
    case INTENTS.BOOK_APPOINTMENT:
      response = buildBookingResponse(message);
      break;
    case INTENTS.ASK_TIMINGS:
      response = buildTimingsResponse();
      break;
    case INTENTS.ASK_SERVICES:
      response = buildServicesResponse();
      break;
    case INTENTS.GENERAL_QUERY:
    default:
      response = buildGeneralResponse(message);
      break;
  }

  logger.info("Response generated", { intent: response.intent });
  return response;
}

module.exports = { processMessage };
