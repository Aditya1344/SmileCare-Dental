/**
 * Mock AI (LLM) Service
 * Simulates an AI model for intent detection, service extraction, and date parsing.
 * Improved over the base mock to handle more natural language patterns.
 */

const clinicData = require("../data/clinicData");

// ─── Intent Detection ────────────────────────────────────────────────────────

const INTENTS = {
  BOOK_APPOINTMENT: "BOOK_APPOINTMENT",
  ASK_TIMINGS:      "ASK_TIMINGS",
  ASK_SERVICES:     "ASK_SERVICES",
  GENERAL_QUERY:    "GENERAL_QUERY",
};

/**
 * Detects the user's intent from their message.
 * Priority: BOOK > TIMINGS > SERVICES > GENERAL
 */
async function callLLM(message) {
  const msg = message.toLowerCase().trim();

  // Booking intent — covers "book", "schedule", "appointment", "fix", "reserve"
  if (/book|schedule|appointment|fix an appt|reserve|want to (get|have)|can i (get|have|book)/.test(msg)) {
    return { intent: INTENTS.BOOK_APPOINTMENT };
  }

  // Timings intent — covers "timing", "hours", "open", "available", "when"
  if (/timing|hours?|open|available|when do you|what time|working hour|schedule/.test(msg)) {
    return { intent: INTENTS.ASK_TIMINGS };
  }

  // Services intent — covers "service", "offer", "provide", "treatment", "do you have"
  if (/service|offer|provide|treatment|procedure|what do you (do|have)|available service/.test(msg)) {
    return { intent: INTENTS.ASK_SERVICES };
  }

  return { intent: INTENTS.GENERAL_QUERY };
}

// ─── Service Extraction ───────────────────────────────────────────────────────

/**
 * Extracts the dental service name from a message.
 * Matches against all service keywords defined in clinicData.
 * @returns {string|null} Matched service name or null
 */
function extractService(message) {
  const msg = message.toLowerCase();
  for (const service of clinicData.services) {
    if (service.keywords.some((kw) => msg.includes(kw))) {
      return service.name;
    }
  }
  return null;
}

// ─── Date Extraction ──────────────────────────────────────────────────────────

/**
 * Extracts a date reference from a message.
 * Handles: "tomorrow", "today", "next week", "monday" etc.
 * @returns {string|null} Date string or null
 */
function extractDate(message) {
  const msg = message.toLowerCase();

  const relativeDates = [
    { pattern: /\btomorrow\b/,                    label: "Tomorrow" },
    { pattern: /\btoday\b/,                       label: "Today" },
    { pattern: /\bnext week\b/,                   label: "Next Week" },
    { pattern: /\bthis week\b/,                   label: "This Week" },
    { pattern: /\bmonday\b/,                      label: "Monday" },
    { pattern: /\btuesday\b/,                     label: "Tuesday" },
    { pattern: /\bwednesday\b/,                   label: "Wednesday" },
    { pattern: /\bthursday\b/,                    label: "Thursday" },
    { pattern: /\bfriday\b/,                      label: "Friday" },
  ];

  for (const { pattern, label } of relativeDates) {
    if (pattern.test(msg)) return label;
  }

  // Match date formats: "15th June", "June 15", "15/06", "2025-06-15"
  const datePatterns = [
    /\b(\d{1,2}(?:st|nd|rd|th)?\s+(?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?))\b/i,
    /\b((?:jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\s+\d{1,2}(?:st|nd|rd|th)?)\b/i,
    /\b(\d{1,2}[\/\-]\d{1,2}(?:[\/\-]\d{2,4})?)\b/,
  ];

  for (const pattern of datePatterns) {
    const match = msg.match(pattern);
    if (match) return match[1];
  }

  return null;
}

module.exports = { callLLM, extractService, extractDate, INTENTS };
