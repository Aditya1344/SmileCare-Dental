# 🦷 SmileCare Dental — AI Agent Backend

An Express.js AI Agent backend that handles natural-language conversations for SmileCare Dental. Supports intent detection, appointment booking, and business queries.

---

## 🚀 Quick Start

### Prerequisites
- Node.js v18+
- npm

### Installation

```bash
# 1. Clone the repository
git clone https://github.com/<your-username>/smilecare-dental-ai.git
cd smilecare-dental-ai

# 2. Install dependencies
npm install

# 3. Start the server
node app.js
```

Server starts at **http://localhost:3000**

---

## 📁 Project Structure

```
smilecare-dental-ai/
├── app.js                    ← 🟢 MAIN ENTRY POINT — run this
├── package.json
├── .env
├── .gitignore
├── tests/
│   └── chat.test.js          ← Jest unit tests (12 test cases)
└── src/
    ├── controllers/
    │   └── chatController.js ← HTTP req/res handling
    ├── services/
    │   └── agentService.js   ← Core business logic & response builder
    ├── routes/
    │   └── chatRoutes.js     ← API route definitions
    ├── utils/
    │   ├── mockAI.js         ← Mock LLM: intent detection, service/date extraction
    │   ├── validators.js     ← Input validation middleware
    │   ├── errorHandler.js   ← Global 404 & error middleware
    │   └── logger.js         ← Timestamped logging utility
    └── data/
        └── clinicData.js     ← Clinic info (hours, services, contact)
```

---

## 🔌 API Reference

### `POST /chat`

Send a message to the AI agent.

**Request Body:**
```json
{ "message": "I want to book a teeth cleaning appointment tomorrow" }
```

**Response:**
```json
{
  "success": true,
  "reply": "Sure! I can help you book a Dental Cleaning appointment on Tomorrow...",
  "intent": "BOOK_APPOINTMENT",
  "service": "Dental Cleaning",
  "date": "Tomorrow"
}
```

### `GET /health`
```json
{ "success": true, "status": "OK", "clinic": "SmileCare Dental AI Agent" }
```

---

## 🎯 Supported Intents

| Intent | Trigger Keywords | Example |
|---|---|---|
| `BOOK_APPOINTMENT` | book, schedule, appointment | "Book root canal tomorrow" |
| `ASK_TIMINGS` | timing, hours, open, when | "What are your timings?" |
| `ASK_SERVICES` | service, offer, provide | "What services do you provide?" |
| `GENERAL_QUERY` | anything else | "Hello", "Thank you" |

---

## 🧪 Sample cURL Requests

```bash
# Book an appointment
curl -X POST http://localhost:3000/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Book braces tomorrow"}'

# Ask about timings
curl -X POST http://localhost:3000/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "What are your timings?"}'

# Ask about services
curl -X POST http://localhost:3000/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "What services do you provide?"}'

# General query
curl -X POST http://localhost:3000/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Hello"}'

# Health check
curl http://localhost:3000/health
```

---

## 🧪 Running Tests

```bash
npm test
```

12 test cases covering all 4 intents, input validation, and edge cases.

---

## 🏗️ Architecture

```
User Request
     │
     ▼
POST /chat (Express Route)
     │
     ▼
Validation Middleware (express-validator)
     │
     ▼
Chat Controller (chatController.js)
     │
     ▼
Agent Service (agentService.js)
   ├── callLLM()        → Detect intent (mockAI.js)
   ├── extractService() → Parse dental service from message
   ├── extractDate()    → Parse date from message
   └── buildResponse()  → Generate context-aware reply using clinicData.js
     │
     ▼
JSON Response → Client
```

**Key Design Decisions:**
- **Separation of concerns** — routes → controller → service → utils/data
- **Improved mock LLM** — regex patterns for broader natural language coverage
- **Centralized data** — all clinic info in `clinicData.js` (easy to update)
- **Input validation** — rejects empty/missing messages with clear error messages
- **Structured logging** — timestamped logs at INFO/DEBUG/ERROR levels

---

## 📋 Business Info

| Field | Value |
|---|---|
| Clinic | SmileCare Dental |
| Hours | Monday–Friday, 10 AM – 7 PM |
| Phone | 9876543210 |
| Email | support@smilecare.com |
| Services | Dental Cleaning, Root Canal, Braces, Teeth Whitening |
