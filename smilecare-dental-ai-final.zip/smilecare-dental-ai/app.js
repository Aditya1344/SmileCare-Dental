/**
 * app.js — SmileCare Dental AI Agent
 * Main entry point. Sets up Express server with all middleware and routes.
 *
 * Run with:  node app.js
 * Dev mode:  npx nodemon app.js
 *
 * UI available at: http://localhost:3000
 */

require("dotenv").config();

const express = require("express");
const cors    = require("cors");
const morgan  = require("morgan");
const path    = require("path");

const chatRoutes                              = require("./src/routes/chatRoutes");
const { notFoundHandler, globalErrorHandler } = require("./src/utils/errorHandler");
const logger                                  = require("./src/utils/logger");

const app  = express();
const PORT = process.env.PORT || 3000;

// ─── Middleware ───────────────────────────────────────────────────────────────

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan("dev"));

// ─── Static UI ───────────────────────────────────────────────────────────────
// Serves public/index.html at http://localhost:3000

app.use(express.static(path.join(__dirname, "public")));

// ─── API Routes ──────────────────────────────────────────────────────────────

app.use("/", chatRoutes);

// ─── Error Handling ───────────────────────────────────────────────────────────

app.use(notFoundHandler);
app.use(globalErrorHandler);

// ─── Start Server ─────────────────────────────────────────────────────────────

app.listen(PORT, () => {
  logger.info(`SmileCare Dental AI Agent running at http://localhost:${PORT}`);
  logger.info(`Chat UI available at      http://localhost:${PORT}`);
  logger.info(`Environment: ${process.env.NODE_ENV || "development"}`);
});

module.exports = app;
