/**
 * Validation Middleware
 * Validates incoming request bodies before they hit the controller.
 */

const { body, validationResult } = require("express-validator");

// Rules for POST /chat
const chatValidationRules = [
  body("message")
    .exists({ checkFalsy: true })
    .withMessage("Message is required.")
    .isString()
    .withMessage("Message must be a string.")
    .trim()
    .isLength({ min: 1, max: 1000 })
    .withMessage("Message must be between 1 and 1000 characters."),
];

// Middleware that returns 400 if validation fails
function validate(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      errors: errors.array().map((e) => ({ field: e.path, message: e.msg })),
    });
  }
  next();
}

module.exports = { chatValidationRules, validate };
