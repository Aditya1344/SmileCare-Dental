/**
 * SmileCare Dental - Business Data
 * Central source of truth for all clinic-related information
 */

const clinicData = {
  name: "SmileCare Dental",
  phone: "9876543210",
  email: "support@smilecare.com",
  operatingHours: {
    days: "Monday - Friday",
    open: "10:00 AM",
    close: "7:00 PM",
    humanReadable: "Monday to Friday from 10 AM to 7 PM",
  },
  services: [
    { id: "dental_cleaning", name: "Dental Cleaning", keywords: ["cleaning", "clean", "teeth clean"] },
    { id: "root_canal",      name: "Root Canal",      keywords: ["root canal", "root", "canal"] },
    { id: "braces",          name: "Braces",          keywords: ["braces", "brace", "orthodontic"] },
    { id: "teeth_whitening", name: "Teeth Whitening", keywords: ["whitening", "whiten", "white"] },
  ],
};

module.exports = clinicData;
