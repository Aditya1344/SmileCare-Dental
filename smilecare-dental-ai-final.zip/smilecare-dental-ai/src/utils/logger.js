/**
 * Simple logger utility with timestamps and log levels
 */

const LOG_LEVELS = { INFO: "INFO", WARN: "WARN", ERROR: "ERROR", DEBUG: "DEBUG" };

function formatLog(level, message, meta = null) {
  const timestamp = new Date().toISOString();
  const base = `[${timestamp}] [${level}] ${message}`;
  return meta ? `${base} | ${JSON.stringify(meta)}` : base;
}

const logger = {
  info:  (msg, meta) => console.log(formatLog(LOG_LEVELS.INFO,  msg, meta)),
  warn:  (msg, meta) => console.warn(formatLog(LOG_LEVELS.WARN,  msg, meta)),
  error: (msg, meta) => console.error(formatLog(LOG_LEVELS.ERROR, msg, meta)),
  debug: (msg, meta) => {
    if (process.env.DEBUG === "true") console.log(formatLog(LOG_LEVELS.DEBUG, msg, meta));
  },
};

module.exports = logger;
