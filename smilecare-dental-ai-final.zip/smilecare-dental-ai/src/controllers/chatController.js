/**
 * Chat Controller
 * Handles HTTP request/response cycle for the /chat endpoint.
 * Delegates business logic to agentService.
 */

const { processMessage } = require("../services/agentService");
const logger = require("../utils/logger");

/**
 * POST /chat
 * Accepts a user message and returns an AI-generated response.
 */
async function handleChat(req, res) {
  const { message } = req.body;

  try {
    const result = await processMessage(message.trim());

    return res.status(200).json({
      success: true,
      ...result,
    });
  } catch (error) {
    logger.error("Chat handler error", { error: error.message });
    return res.status(500).json({
      success: false,
      reply: "Something went wrong on our end. Please try again later.",
      intent: "ERROR",
    });
  }
}

/**
 * GET /health
 * Simple health check endpoint.
 */
function healthCheck(req, res) {
  return res.status(200).json({
    success: true,
    status: "OK",
    clinic: "SmileCare Dental AI Agent",
    timestamp: new Date().toISOString(),
  });
}

module.exports = { handleChat, healthCheck };
