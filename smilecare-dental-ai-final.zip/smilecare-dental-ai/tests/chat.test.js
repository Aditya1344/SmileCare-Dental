/**
 * Unit Tests — SmileCare Dental AI Agent
 * Tests all 4 intent types, edge cases, and validation.
 *
 * Run: npm test
 */

const request = require("supertest");
const app     = require("../app");

describe("SmileCare Dental AI Agent — POST /chat", () => {

  // ── Intent: ASK_TIMINGS ────────────────────────────────────────────────────
  describe("ASK_TIMINGS", () => {
    test("returns timings for 'What are your timings?'", async () => {
      const res = await request(app)
        .post("/chat")
        .send({ message: "What are your timings?" });

      expect(res.statusCode).toBe(200);
      expect(res.body.intent).toBe("ASK_TIMINGS");
      expect(res.body.reply).toMatch(/Monday/i);
    });

    test("handles 'What are your working hours?'", async () => {
      const res = await request(app)
        .post("/chat")
        .send({ message: "What are your working hours?" });

      expect(res.body.intent).toBe("ASK_TIMINGS");
    });
  });

  // ── Intent: ASK_SERVICES ───────────────────────────────────────────────────
  describe("ASK_SERVICES", () => {
    test("returns services for 'What services do you provide?'", async () => {
      const res = await request(app)
        .post("/chat")
        .send({ message: "What services do you provide?" });

      expect(res.statusCode).toBe(200);
      expect(res.body.intent).toBe("ASK_SERVICES");
      expect(res.body.reply).toMatch(/Dental Cleaning/i);
    });
  });

  // ── Intent: BOOK_APPOINTMENT ───────────────────────────────────────────────
  describe("BOOK_APPOINTMENT", () => {
    test("books braces appointment tomorrow", async () => {
      const res = await request(app)
        .post("/chat")
        .send({ message: "Book braces tomorrow" });

      expect(res.statusCode).toBe(200);
      expect(res.body.intent).toBe("BOOK_APPOINTMENT");
      expect(res.body.service).toBe("Braces");
      expect(res.body.date).toBe("Tomorrow");
    });

    test("books root canal appointment", async () => {
      const res = await request(app)
        .post("/chat")
        .send({ message: "Book root canal tomorrow" });

      expect(res.body.intent).toBe("BOOK_APPOINTMENT");
      expect(res.body.service).toBe("Root Canal");
    });

    test("books teeth whitening without a date", async () => {
      const res = await request(app)
        .post("/chat")
        .send({ message: "I want to book teeth whitening" });

      expect(res.body.intent).toBe("BOOK_APPOINTMENT");
      expect(res.body.service).toBe("Teeth Whitening");
      expect(res.body.date).toBeNull();
    });

    test("handles booking with no service or date", async () => {
      const res = await request(app)
        .post("/chat")
        .send({ message: "I want to book an appointment" });

      expect(res.body.intent).toBe("BOOK_APPOINTMENT");
      expect(res.body.service).toBeNull();
      expect(res.body.date).toBeNull();
    });
  });

  // ── Intent: GENERAL_QUERY ──────────────────────────────────────────────────
  describe("GENERAL_QUERY", () => {
    test("returns greeting for 'Hello'", async () => {
      const res = await request(app)
        .post("/chat")
        .send({ message: "Hello" });

      expect(res.statusCode).toBe(200);
      expect(res.body.intent).toBe("GENERAL_QUERY");
      expect(res.body.reply).toMatch(/welcome|hello|hi/i);
    });

    test("handles thank you message", async () => {
      const res = await request(app)
        .post("/chat")
        .send({ message: "Thank you!" });

      expect(res.body.intent).toBe("GENERAL_QUERY");
      expect(res.body.reply).toMatch(/welcome/i);
    });
  });

  // ── Validation ─────────────────────────────────────────────────────────────
  describe("Input Validation", () => {
    test("returns 400 for empty message", async () => {
      const res = await request(app)
        .post("/chat")
        .send({ message: "" });

      expect(res.statusCode).toBe(400);
      expect(res.body.success).toBe(false);
    });

    test("returns 400 for missing message field", async () => {
      const res = await request(app)
        .post("/chat")
        .send({});

      expect(res.statusCode).toBe(400);
    });
  });

  // ── Health Check ───────────────────────────────────────────────────────────
  describe("GET /health", () => {
    test("returns 200 OK", async () => {
      const res = await request(app).get("/health");
      expect(res.statusCode).toBe(200);
      expect(res.body.status).toBe("OK");
    });
  });

});
