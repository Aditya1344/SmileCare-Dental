/**
 * Error Handling Middleware
 * Catches any unhandled errors in the Express pipeline.
 */

const logger = require("../utils/logger");

// 404 handler — for undefined routes
function notFoundHandler(req, res, next) {
  res.status(404).json({
    success: false,
    error: `Route ${req.method} ${req.originalUrl} not found.`,
    hint: "Available endpoint: POST /chat",
  });
}

// Global error handler
function globalErrorHandler(err, req, res, next) {
  logger.error("Unhandled error", { message: err.message, stack: err.stack });

  const status = err.status || 500;
  res.status(status).json({
    success: false,
    error: status === 500 ? "Internal Server Error" : err.message,
  });
}

module.exports = { notFoundHandler, globalErrorHandler };
